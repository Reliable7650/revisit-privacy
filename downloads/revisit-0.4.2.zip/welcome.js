(() => {
  const { locale, t } = globalThis.RevisitI18n;
  document.documentElement.lang = locale;
  document.title = t('welcomePageTitle');
  document.querySelectorAll('[data-i18n]').forEach((element) => {
    element.textContent = t(element.dataset.i18n);
  });
  const element = (id) => document.getElementById(id);
  let state;
  let busy = false;
  let refreshing;
  let refreshVersion = 0;
  let refreshTimer;
  let pollTimer;

  async function send(type, values = {}) {
    const response = await chrome.runtime.sendMessage({ type, ...values });
    if (!response?.ok) throw Object.assign(new Error(response?.error?.message || t('operationFailed')), { code: response?.error?.code });
    return response.data;
  }

  function status(message = '', isError = false) {
    element('status').textContent = message;
    element('status').dataset.error = String(isError);
  }

  function render() {
    if (!state) return;
    const mastodon = state.platform === 'mastodon';
    const platform = mastodon ? t('platformMastodon') : 'X';
    document.querySelectorAll('[data-i18n]').forEach((item) => {
      item.textContent = t(item.dataset.i18n, { platform });
    });
    const home = mastodon ? 'https://m.cmx.im/home' : 'https://x.com/home';
    element('open-platform').href = home;
    element('open-home').href = home;
    const unlocked = state.vaultStatus === 'unlocked' && state.collectionAllowed === true;
    const migration = state.vaultStatus === 'migration-required';
    element('consent-panel').hidden = unlocked || migration;
    element('setup-steps').hidden = !unlocked;
    element('migration-panel').hidden = !migration;
    element('ready').hidden = true;
    element('accept').disabled = busy;
    if (migration) {
      element('migration-body').textContent = t(state.vaultError ? 'vaultCorrupt' : 'welcomeMigrationBody');
      return;
    }
    if (!unlocked) return;

    const username = state.user?.username || '';
    const count = state.bookmarkCount || 0;
    const history = mastodon ? {} : state.historyRuntime || {};
    const running = history.status === 'starting' || history.status === 'reading';
    const hasCollected = count > 0 || (history.addedCount || 0) > 0;
    const canLoadMore = Boolean(username) && !running && history.status !== 'ended';
    element('step-signin').classList.toggle('is-complete', Boolean(username) || count > 0);
    element('step-collect').classList.toggle('is-complete', history.status === 'ended');
    element('step-more').hidden = !username;
    element('collect-status').textContent = count > 0
      ? t('welcomeCollected', { count: new Intl.NumberFormat(locale).format(count) })
      : username
        ? t('welcomeWaitingForBookmarks', { platform })
        : t('welcomeWaitingForAccount', { platform });
    element('step-more-body').textContent = t(mastodon ? 'oldBookmarksGuide' : 'welcomeStepMoreBody');
    element('load-more').textContent = t(mastodon ? 'bookmarksGuideAction' : 'welcomeLoadMore');
    element('history-status').textContent = history.status && history.status !== 'idle'
      ? t('welcomeHistoryStatus', {
        status: t(`history_${history.status.replaceAll('-', '_')}`),
        added: new Intl.NumberFormat(locale).format(history.addedCount || 0),
      })
      : '';
    element('history-hint').hidden = !running;
    element('open-bookmarks').disabled = busy;
    element('load-more').hidden = !canLoadMore;
    element('load-more').disabled = busy;
    element('stop-history').hidden = !running;
    element('stop-history').disabled = busy;
    element('ready').hidden = !(hasCollected || running);
    document.querySelectorAll('button, input').forEach((control) => {
      control.disabled = busy;
    });
    element('open-bookmarks').disabled = busy;
    element('load-more').disabled = busy;
    element('stop-history').disabled = busy;
  }

  async function refresh(force = false) {
    if (force) { refreshVersion++; refreshing = undefined; }
    if (refreshing) return refreshing;
    const version = refreshVersion;
    const pending = send('GET_STATE').then((data) => {
      if (version !== refreshVersion) return;
      state = data;
      render();
    }).finally(() => { if (refreshing === pending) refreshing = undefined; });
    refreshing = pending;
    return pending;
  }

  async function run(type, values, successKey) {
    if (busy) return;
    busy = true;
    status(t('working'));
    render();
    try {
      await send(type, values);
      await refresh(true);
      status(successKey ? t(successKey) : '');
    } catch (error) {
      status(`${t('operationFailed')} ${error.message}`, true);
      await refresh().catch(() => {});
    } finally {
      busy = false;
      render();
    }
  }

  element('accept').addEventListener('click', () => run('ACCEPT_COLLECTION', {}, 'welcomeStarted'));
  element('open-bookmarks').addEventListener('click', async () => {
    try {
      await send('OPEN_BOOKMARKS', { platform: state?.platform || 'x' });
      status(t('welcomeBookmarksOpened'));
    } catch (error) {
      status(`${t('operationFailed')} ${error.message}`, true);
    }
  });
  element('load-more').addEventListener('click', () => {
    if (state?.platform === 'mastodon') {
      run('OPEN_BOOKMARKS', { platform: 'mastodon' });
      return;
    }
    if (!state?.user?.username) {
      status(t('historyAccountRequired'), true);
      return;
    }
    element('history-consent').showModal?.();
  });
  element('history-cancel').addEventListener('click', () => {
    element('history-consent').close?.();
  });
  element('history-agree').addEventListener('click', () => {
    element('history-consent').close?.();
    if (state?.platform === 'mastodon') return;
    run('START_HISTORY', { accountUsername: state.user.username, consent: true }, 'welcomeHistoryStarted');
  });
  element('stop-history').addEventListener('click', () => {
    run('STOP_HISTORY', {}, 'welcomeHistoryStopped');
  });

  function scheduleRefresh() {
    clearTimeout(refreshTimer);
    refreshTimer = setTimeout(() => {
      refresh().catch((error) => status(`${t('operationFailed')} ${error.message}`, true));
    }, 80);
  }
  chrome.storage.onChanged.addListener((_, area) => {
    if (area === 'local') scheduleRefresh();
  });
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === 'STATE_CHANGED') scheduleRefresh();
  });
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') {
      refresh().catch((error) => status(`${t('operationFailed')} ${error.message}`, true));
    }
  });
  window.addEventListener('pagehide', () => clearInterval(pollTimer));
  refresh().catch((error) => status(`${t('operationFailed')} ${error.message}`, true));
  pollTimer = setInterval(() => {
    if (state?.collectionAllowed && document.visibilityState === 'visible') {
      refresh().catch(() => {});
    }
  }, 2500);
})();
