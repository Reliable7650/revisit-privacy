# Revisit Privacy Policy

Last updated: November 18, 2026. Applies to version 0.4.2.

Publisher: ob2. Public contact: hquyenhoang26@duck.com. Revisit is independent and is not affiliated with or endorsed by X, Mastodon or Google.

## Purpose and consent

Revisit automatically resurfaces one locally collected X bookmark on X Home or one locally collected Mastodon bookmark on m.cmx.im Home. No platform selection is needed. It prioritizes posts you have seen least, opens the original post and its replies, and lets you remove or restore that bookmark through an explicit action. Platforms and accounts have separate bookmark libraries and display counts. An optional load-more control can ask X’s web interface for more bookmark pages to display and save their progress locally; Mastodon has no separate authorization page or active batch reader.

A new installation presents an in-product collection disclosure and requires your explicit agreement before collection or saved-content display begins. It does not ask a new user to choose a local password. Your agreement is remembered, and normal use continues without a password prompt after Chrome restarts. You do not need a Revisit account, X developer application, API key or paid API.

Before agreement, Revisit does not read your X or Mastodon account for collection, copy or parse bookmark responses, collect rendered bookmark posts, or show saved post content. First-use guidance for each platform asks you to open its native bookmark page and keep scrolling while older batches load. Only loaded bookmarks can be resurfaced, and a collected count does not mean the entire library has loaded.

## Information handled

After agreement, Revisit handles the platform and visible account username; bookmark and post identifiers; original-post and author links; post text and dates; author names, usernames, profile identifiers and avatar references; media links and alternative text; Mastodon content-warning text and sensitive-media flags; available reply, ordinary repost, quote, like and view totals; bookmark state; display counts; collection times; and settings. Engagement totals are the last collected snapshot, not continuously refreshed counters.

Collection covers bookmarks X loads during normal Bookmarks browsing, including its base History/bookmarks route, and bookmarks m.cmx.im loads on its native /bookmarks page. For Mastodon, Revisit passively observes the native page’s loaded responses and rendered posts; it does not request the next bookmark page or perform an independent authorization flow. Separately, the optional “Save bookmarked posts as you browse” setting is off by default for new and existing users. If enabled, Revisit inspects visible posts during normal X or m.cmx.im browsing and saves a post locally when that website shows it as bookmarked by the current account, including a newly bookmarked post after the website confirms it. It saves displayed post information, not unrelated browsing history or search terms. Turn the setting off at any time to stop this additional collection; previously saved records remain. The ordinary bookmark-page collector excludes Likes and unrelated History sections. When the optional browsing setting is enabled, a visible post elsewhere on X, including another History section, can be saved only if X shows that post as bookmarked by the current account. Responses with an unknown or changed account are discarded. Records are separated by the platform and account shown on the page, including accounts with the same username on different platforms.

The optional “Load more bookmarks for display” control requires a separate agreement. After that agreement, Revisit uses the X session already present in this Chrome profile to read X’s web interface in batches. It stores each page’s posts and an encrypted, per-account continuation position locally, then can resume later. This is not the official X API, does not require an X developer application or paid API, and may be limited or blocked by X. Revisit never claims that the end of one run means every bookmark was retrieved. A stopped, rate-limited, signed-out, changed-account, or unreadable source is recorded separately.

Ordinary X browsing does not start a load-more task. The load-more task runs only after the user presses the control and explicitly accepts the web-interface warning. It can be stopped from the popup; stopping does not delete already saved posts.

Only when migrating an older 0.2.0 password-protected store, Revisit may process the old local password you enter. It is used on your device to open the old store for migration, is not retained, and is not sent to X or the publisher. This is not a new-password requirement and is separate from your X password.

## Automatic local encryption and its limits

Collected posts, account/post relationships, selection data and display counts are encrypted locally with AES-256-GCM. Revisit generates a device key and stores it as a non-extractable CryptoKey in local IndexedDB within the same Chrome profile as the encrypted records. It can use this key automatically after a restart, without asking for a password.

Non-extractable means that normal WebCrypto export operations do not return the key's raw bytes. It does not mean the key is kept outside this profile or that code with access to the stored key cannot use it. This automatic local encryption does not provide the same protection as a separately held password. Revisit does not claim to protect against someone who can read or copy the entire Chrome profile, malware, a compromised browser or another person using the profile.

This is a device-local storage choice, not a statement that Chrome requires a password. No new local password is created, saved or uploaded by the 0.4.0 setup.

## Retention, upgrade and deletion

Encrypted records and the device key remain in this Chrome profile after the browser closes. Revisit does not synchronize them to other devices. Logging out of X or Mastodon does not erase the local store.

For an existing 0.2.0 password-protected store, a valid previously unlocked session can allow automatic migration. Otherwise the extension asks for the old local password once to migrate the saved posts and display counts to device-key storage. After successful migration, normal use and browser restarts do not require that password. If the old password is unavailable and the old store cannot be opened, it cannot be recovered by Revisit; you can instead clear local data and recollect bookmarks from the corresponding website.

Earlier unencrypted development records are migrated only after explicit collection agreement. Old records are removed through the browser's storage APIs after successful migration. This is logical deletion, not a promise of forensic erasure of disk blocks or backups.

Clear local data deletes the local encrypted posts, display records, device key, consent and older local records. It cancels pending helper tabs and returns the extension to the first-consent state. It does not delete your bookmarks on X or Mastodon. After you agree again, newly collected posts start with new display records. Uninstalling also removes extension-local data.

Removing a bookmark through Revisit excludes it from future selection after a confirmed result. Its encrypted content and previous display count are retained so restoring it can preserve history. Changes made elsewhere, deleted/edited posts and access changes may not be reflected until relevant content from that website is loaded again. The local archive is not a guarantee that an original post remains available.

## Website login and explicit bookmark actions

Revisit does not ask for or read your X or Mastodon password. For ordinary native bookmark actions, it does not read Cookie values, authorization headers or anti-forgery headers. For the optional “Load more bookmarks for display” control, it reads the current X session cookies needed to use X’s own web interface: the account identifier and CSRF value. It does not retain or transmit those values to the publisher. The load-more reader also discovers the current X web-client configuration and sends bookmark-page requests from the extension background using that existing browser session. Those requests are visible to X and may be subject to X’s limits and policies.

An explicit bookmark click on the Home card briefly opens the original post in a background tab on the corresponding platform, verifies the matching platform/account/post and uses that website’s own bookmark button. That tab closes after completion, cancellation or failure. The browser supplies its existing login state with native website requests. The original-post visit is visible to the corresponding website. Revisit updates Home state only after the website confirms the result. Mastodon support does not separately extract or store access tokens, cookies or authorization headers.

Clearing local data cancels pending helper tabs and stops further collection until renewed agreement. An action already sent to X or m.cmx.im may still complete on that website; local clearing cannot revoke a request the website has already received. If a result is not confirmed, verify the original post rather than assuming it changed or stayed unchanged.

## Network connections and sharing

Revisit has no bookmark backend, cloud bookmark account, advertising, analytics or tracking system. The publisher does not receive the local bookmark database or device key. Avatar and media references can load content from X or its content-delivery providers, m.cmx.im media services, or the corresponding federated media hosts. Those hosts receive the ordinary browser requests for those resources. Opening originals, reply/repost flows, like/share entry points and explicit helper visits use the corresponding platform’s website and policies. Media references are not an offline download.

All extension logic is bundled. It does not download executable extension code or evaluate remote strings as code. The optional load-more reader fetches X’s web-client scripts to discover the current bookmark operation, then requests bookmark pages from X’s web interface using the existing session. It does not send the bookmark library or session values to the publisher. Relevant responses are treated as data only after collection is allowed.

The public privacy/support website uses GitHub Pages, with an additional Sites deployment. Website visits can involve ordinary hosting access information such as IP address and browser details; this is separate from the extension's local bookmark store. Its source includes no application analytics, advertising scripts, bookmark upload form or login requirement.

If you email support, the email services delivering and answering the request process your contact address and message. Do not send old passwords, cookies, session tokens or private bookmark archives. Share specific support material only if you deliberately choose to do so.

## Controls

The Home display switch controls the card only; it does not stop collection after agreement. Turn off the optional browsing setting to stop that additional collection; closing bookmark pages stops ordinary bookmark-page collection. X’s “Load more bookmarks for display” control has its own consent and Stop action. Mastodon’s older-bookmark entry instead opens the native /bookmarks page and asks you to keep scrolling; it does not start X’s reader. Disable or uninstall the extension to stop all collection. Clear local data revokes stored consent, removes the continuation position, and nothing is recollected until you explicitly agree again. There is no routine password-unlock step or password-based lock mode in 0.4.0.

Revisit depends on X’s and m.cmx.im’s current page structures and native buttons. Changes or restrictions on either website can affect operation. Functional tests, encryption and local operation do not establish X permission or Chrome Web Store approval.

## Limited Use commitment

Revisit's use and transfer of user data adheres to the Limited Use requirements of the Chrome Web Store User Data Policy. Data is used only for the disclosed bookmark collection, resurfacing and management feature. It is not sold, transferred for advertising, used for credit decisions or unrelated profiling. The publisher does not receive the bookmark database and does not allow people to read users' local bookmark content. Specific information deliberately sent for support is handled only for that request.

## Contact and changes

Publisher: ob2. Contact: hquyenhoang26@duck.com.

Questions about local data or this policy may be sent to this public contact. Changes to collection, storage, migration or network behavior must be reflected here and in store declarations before release.

