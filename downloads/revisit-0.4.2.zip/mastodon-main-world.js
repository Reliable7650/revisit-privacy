(() => {
  const origin = 'https://m.cmx.im';
  const numericId = value => typeof value === 'string' && /^[0-9]{1,20}$/.test(value);
  const acct = value => typeof value === 'string' && value.length <= 320 && /^[A-Za-z0-9_.-]+(?:@[A-Za-z0-9.-]+(?::[0-9]+)?)?$/.test(value);

  function webURL(value, media = false) {
    if (typeof value !== 'string') return '';
    try {
      const url = new URL(value);
      return (media ? url.protocol === 'https:' : ['https:', 'http:'].includes(url.protocol)) && !url.username && !url.password ? url.href : '';
    } catch { return ''; }
  }

  function account() {
    const anchor = document.querySelector('.compose-panel .navigation-bar a[href^="/@"], .compose-panel .account__display-name[href], .compose-form .account__display-name[href], .navigation-bar a[href^="/@"]');
    if (!anchor) return '';
    try {
      const url = new URL(anchor.href, location.origin);
      const match = url.pathname.match(/^\/@([A-Za-z0-9_]{1,64})\/?$/);
      return url.origin === origin && match ? `m.cmx.im:${match[1].toLowerCase()}` : '';
    } catch { return ''; }
  }

  function textOf(root, mentions = []) {
    const urls = [];
    function walk(node) {
      if (node.nodeType === 3) return node.textContent;
      if (node.nodeType !== 1 && node.nodeType !== 11) return '';
      const tag = node.nodeName.toLowerCase();
      if (['script', 'style', 'iframe', 'object'].includes(tag)) return '';
      if (tag === 'br') return '\n';
      if (tag === 'img') return node.getAttribute('alt') || '';
      if (tag === 'a') {
        let href = '';
        const rawHref = node.getAttribute('href');
        if (rawHref) try { href = webURL(new URL(rawHref, origin).href); } catch {}
        const text = node.textContent;
        if (href && text.startsWith('@')) {
          const mention = Array.isArray(mentions) && mentions.find(item => item && acct(item.acct) && webURL(item.url) === href);
          if (mention) return `@${mention.acct}`;
          const url = new URL(href);
          const local = url.origin === origin && url.pathname.match(/^\/@([^/]+)\/?$/);
          if (local && acct(local[1])) return `@${local[1]}`;
        }
        if (href && !text.startsWith('#')) {
          urls.push({ url: href, expandedUrl: href, displayUrl: text || href });
          return href;
        }
      }
      const text = Array.from(node.childNodes).map(walk).join('');
      return ['p', 'div', 'blockquote', 'pre', 'li'].includes(tag) ? `${text}\n` : text;
    }
    return { text: walk(root).replace(/\n{3,}/g, '\n\n').trim(), urls };
  }

  function htmlText(value, mentions) {
    const template = document.createElement('template');
    template.innerHTML = value;
    return textOf(template.content, mentions);
  }

  function normalizeStatus(value) {
    if (!value || typeof value !== 'object' || !numericId(value.id) || value.bookmarked === false) return null;
    const author = value.account;
    const username = author?.acct || author?.username;
    if (!author || !numericId(author.id) || !acct(username) || typeof value.content !== 'string' || typeof value.created_at !== 'string' || !Number.isFinite(Date.parse(value.created_at))) return null;
    const name = author.display_name || author.username;
    if (typeof name !== 'string') return null;
    const { text, urls } = htmlText(value.content, value.mentions);
    const profile = `${origin}/@${username}`;
    const metrics = {};
    for (const [key, count] of [['replies', value.replies_count], ['reposts', value.reblogs_count], ['likes', value.favourites_count]]) {
      if (Number.isSafeInteger(count) && count >= 0) metrics[key] = count;
    }
    const media = Array.isArray(value.media_attachments) ? value.media_attachments.flatMap(item => {
      const type = { image: 'photo', video: 'video', gifv: 'animated_gif' }[item?.type];
      const url = webURL(item?.url, true);
      const previewUrl = webURL(item?.preview_url, true);
      if (!type || (!url && !previewUrl)) return [];
      return [{ type, url, previewUrl, altText: typeof item.description === 'string' ? item.description : '' }];
    }) : [];
    const lang = typeof value.language === 'string' && /^[A-Za-z]{2,8}(?:-[A-Za-z0-9]{1,8})*$/.test(value.language) ? value.language : '';
    const avatarStatic = webURL(author.avatar_static, true);
    const avatar = webURL(author.avatar, true);
    return {
      platform: 'mastodon', id: value.id, url: `${profile}/${value.id}`, text, createdAt: value.created_at,
      author: { id: author.id, name, username, url: profile, avatar: avatarStatic || avatar, ...(avatarStatic && avatar && avatarStatic !== avatar ? { avatarFallback: avatar } : {}) },
      media, urls, sensitive: value.sensitive === true, spoilerText: typeof value.spoiler_text === 'string' ? value.spoiler_text : '',
      ...(lang ? { lang } : {}), ...(Object.keys(metrics).length ? { metrics } : {}),
    };
  }

  function extractPosts(payload) {
    if (!Array.isArray(payload)) return [];
    const posts = new Map();
    for (const value of payload) {
      const post = normalizeStatus(value);
      if (post && !posts.has(post.id)) posts.set(post.id, post);
    }
    return [...posts.values()];
  }

  function postFromElement(article) {
    const permalink = article.querySelector('a.status__relative-time');
    const time = permalink?.querySelector('time');
    const href = permalink?.getAttribute('href');
    const match = href && new URL(href, origin).pathname.match(/^\/@([^/]+)\/([0-9]{1,20})\/?$/);
    if (!match || !acct(match[1]) || !time?.dateTime || !Number.isFinite(Date.parse(time.dateTime))) return null;
    const username = match[1];
    const profile = `${origin}/@${username}`;
    const content = article.querySelector('.status__content__text');
    const { text, urls } = content ? textOf(content) : { text: '', urls: [] };
    const avatar = article.querySelector('.account__avatar img');
    const name = article.querySelector('.display-name__html');
    const spoiler = article.querySelector('.status__content__spoiler-text');
    const media = Array.from(article.querySelectorAll('.media-gallery img')).flatMap(img => {
      const url = webURL(img.getAttribute('src'), true);
      return url ? [{ type: 'photo', url, previewUrl: '', altText: img.getAttribute('alt') || '' }] : [];
    });
    const lang = content?.getAttribute('lang');
    return {
      platform: 'mastodon', id: match[2], url: `${profile}/${match[2]}`, text, createdAt: time.dateTime,
      author: { id: username, username, name: name?.textContent || username, url: profile, avatar: webURL(avatar?.getAttribute('src'), true) },
      media, urls, partial: true, sensitive: Boolean(article.querySelector('.spoiler-button, .media-spoiler')), spoilerText: spoiler?.textContent || '',
      ...(lang && /^[A-Za-z]{2,8}(?:-[A-Za-z0-9]{1,8})*$/.test(lang) ? { lang } : {}),
    };
  }

  function parseOperation(value, method = 'GET') {
    try {
      const url = new URL(value, origin);
      if (url.origin !== origin || url.username || url.password) return null;
      if (url.pathname === '/api/v1/bookmarks' && method.toUpperCase() === 'GET') return { operation: 'bookmarks' };
      const match = url.pathname.match(/^\/api\/v1\/statuses\/([0-9]{1,20})\/(bookmark|unbookmark)$/);
      return match && method.toUpperCase() === 'POST' ? { operation: match[2], postId: match[1] } : null;
    } catch { return null; }
  }

  globalThis.RevisitMastodonData = Object.freeze({ account, extractPosts, normalizeStatus, postFromElement, parseOperation, isBookmarksPage: () => /^\/bookmarks\/?$/.test(location.pathname) });
})();

(() => {
  if (window.top !== window || globalThis.__revisitPageInstalled) return;
  globalThis.__revisitPageInstalled = true;
  const { account, isBookmarksPage, parseOperation, extractPosts } = globalThis.RevisitMastodonData;
  const nativeFetch = window.fetch;
  let channel, enabled = false, activeAccount = '', epoch = 0;
  let xhrRequests = new WeakMap();
  function checkAccount() {
    if (!enabled) return;
    const next = account();
    if (next !== activeAccount) { epoch++; activeAccount = next; }
  }
  const accountObserver = new MutationObserver(checkAccount);
  function emit(type, data) {
    if (channel) window.postMessage({ source: 'revisit-page', channel, type, ...data }, location.origin);
  }
  function metadata(input, init = {}) {
    if (!enabled) return null;
    let url;
    try { url = new URL(typeof input === 'string' || input instanceof URL ? input : input.url, location.href); } catch { return null; }
    const parsed = parseOperation(url.href, init.method || (typeof input === 'object' && input.method) || 'GET');
    if (!parsed || (parsed.operation === 'bookmarks' && !isBookmarksPage())) return null;
    checkAccount();
    return activeAccount ? { ...parsed, account: activeAccount, epoch } : null;
  }
  function current(request) {
    if (!enabled) return false;
    checkAccount();
    return request.account === activeAccount && request.epoch === epoch;
  }
  function result(request, payload) {
    if (!current(request)) return;
    if (request.operation === 'bookmarks') {
      if (!isBookmarksPage()) return;
      const posts = extractPosts(payload);
      if (posts.length) emit('POSTS', { accountUsername: request.account, posts });
    } else if (payload?.id === request.postId && payload.bookmarked === (request.operation === 'bookmark') && !payload.error) {
      emit('MUTATION', { accountUsername: request.account, postId: request.postId, bookmarked: payload.bookmarked });
    }
  }
  window.fetch = function(input, init) {
    let request;
    try { request = metadata(input, init); } catch {}
    const pending = Reflect.apply(nativeFetch, this, arguments);
    if (request) pending.then(response => {
      if (response.ok && current(request)) response.clone().json().then(payload => result(request, payload)).catch(() => {});
    }, () => {}).catch(() => {});
    return pending;
  };
  const open = XMLHttpRequest.prototype.open;
  const send = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function(method, url) {
    if (enabled) xhrRequests.set(this, { method, url });
    return Reflect.apply(open, this, arguments);
  };
  XMLHttpRequest.prototype.send = function() {
    let request;
    try {
      const item = xhrRequests.get(this);
      if (item) request = metadata(String(item.url), { method: item.method });
    } catch {}
    if (request) this.addEventListener('loadend', () => {
      try {
        if (this.status < 200 || this.status >= 300 || !current(request)) return;
        result(request, this.responseType === 'json' ? this.response : JSON.parse(this.responseText));
      } catch {}
    }, { once: true });
    return Reflect.apply(send, this, arguments);
  };
  window.addEventListener('message', event => {
    if (event.source !== window || event.origin !== location.origin || event.data?.source !== 'revisit-content') return;
    const data = event.data;
    if (data.type === 'INIT' && typeof data.channel === 'string') { channel = data.channel; return; }
    if (!channel || data.channel !== channel) return;
    if (data.type === 'DISABLE') {
      enabled = false; epoch++; activeAccount = ''; xhrRequests = new WeakMap(); accountObserver.disconnect();
    } else if (data.type === 'ENABLE') {
      if (!enabled) {
        enabled = true; epoch++; activeAccount = '';
        accountObserver.observe(document, { childList: true, subtree: true });
      }
      emit('ENABLED', { requestId: data.requestId });
    }
  });
  window.postMessage({ source: 'revisit-page', type: 'READY' }, location.origin);
})();
