(() => {
  const operations = new Set(['Bookmarks', 'BookmarksAll', 'CreateBookmark', 'DeleteBookmark']);
  const record = value => value !== null && typeof value === 'object' && !Array.isArray(value);
  const numericId = value => typeof value === 'string' && /^\d+$/.test(value);

  function webURL(value) {
    if (typeof value !== 'string') return '';
    try {
      const url = new URL(value);
      return ['https:', 'http:'].includes(url.protocol) && !url.username && !url.password ? url.href : '';
    } catch { return ''; }
  }

  function parseOperation(value) {
    if (typeof value !== 'string') return null;
    try {
      const url = new URL(value, 'https://x.com');
      if (url.origin !== 'https://x.com' || url.username || url.password) return null;
      const match = url.pathname.match(/^\/i\/api\/graphql\/([A-Za-z0-9_-]{1,256})\/([A-Za-z][A-Za-z0-9_]{0,127})$/);
      if (!match || !operations.has(match[2])) return null;
      return { queryId: match[1], operation: match[2] };
    } catch { return null; }
  }

  function normalizeTweet(result) {
    const tweet = result?.__typename === 'TweetWithVisibilityResults' ? result.tweet : result;
    if (!record(tweet)) return null;
    const legacy = record(tweet.legacy) ? tweet.legacy : {};
    if (legacy.bookmarked !== true) return null;
    const id = tweet.rest_id || legacy.id_str;
    const userResult = tweet.core?.user_results?.result;
    const user = userResult?.__typename === 'UserWithVisibilityResults' ? userResult.user : userResult;
    if (!numericId(id) || !record(user)) return null;
    const userLegacy = record(user.legacy) ? user.legacy : {};
    const username = user.core?.screen_name || userLegacy.screen_name;
    const name = user.core?.name || userLegacy.name;
    const authorId = user.rest_id || userLegacy.id_str;
    const createdAt = legacy.created_at || tweet.created_at;
    const lang = typeof legacy.lang === 'string' && /^[A-Za-z]{2,8}(?:-[A-Za-z0-9]{1,8})*$/.test(legacy.lang) ? legacy.lang : '';
    const note = tweet.note_tweet?.note_tweet_results?.result;
    const text = typeof note?.text === 'string' ? note.text : legacy.full_text;
    if (!numericId(authorId) || typeof username !== 'string' || !/^[A-Za-z0-9_]{1,50}$/.test(username)
      || typeof name !== 'string' || typeof text !== 'string' || typeof createdAt !== 'string'
      || !Number.isFinite(Date.parse(createdAt))) return null;
    const entities = note?.entity_set || note?.entities || legacy.entities || {};
    const rawMedia = legacy.extended_entities?.media || legacy.entities?.media || [];
    const media = Array.isArray(rawMedia) ? rawMedia.flatMap(item => {
      if (!record(item) || !['photo', 'video', 'animated_gif'].includes(item.type)) return [];
      const image = webURL(item.media_url_https || item.media_url);
      if (!image) return [];
      return [{ type: item.type, url: item.type === 'photo' ? image : '', previewUrl: image, altText: typeof item.ext_alt_text === 'string' ? item.ext_alt_text : '' }];
    }) : [];
    const urls = Array.isArray(entities.urls) ? entities.urls.flatMap(item => {
      if (!record(item)) return [];
      const url = webURL(item.url);
      if (!url) return [];
      return [{ url, displayUrl: typeof item.display_url === 'string' ? item.display_url : item.url, expandedUrl: webURL(item.expanded_url) }];
    }) : [];
    const metrics = {};
    for (const [key, value] of [['replies', legacy.reply_count], ['reposts', legacy.retweet_count], ['likes', legacy.favorite_count], ['views', tweet.views?.count]]) {
      const count = typeof value === 'string' && /^\d+$/.test(value) ? Number(value) : value;
      if (typeof count === 'number' && Number.isSafeInteger(count) && count >= 0) metrics[key] = count;
    }
    const quotes = typeof legacy.quote_count === 'string' && /^\d+$/.test(legacy.quote_count) ? Number(legacy.quote_count) : legacy.quote_count;
    if (Object.hasOwn(metrics, 'reposts') && typeof quotes === 'number' && Number.isSafeInteger(quotes) && quotes >= 0) {
      const total = metrics.reposts + quotes;
      if (Number.isSafeInteger(total)) metrics.reposts = total;
    }
    return {
      id, text, createdAt, ...(lang ? { lang } : {}),
      author: { id: authorId, name, username, avatar: webURL(user.avatar?.image_url || userLegacy.profile_image_url_https || userLegacy.profile_image_url) },
      media, urls, ...(Object.keys(metrics).length ? { metrics } : {}),
    };
  }

  function bookmarkTimeline(payload) {
    if (!record(payload) || (payload.errors !== undefined && (!Array.isArray(payload.errors) || payload.errors.length))) return null;
    const timeline = payload.data?.bookmark_timeline_v2?.timeline || payload.data?.bookmark_timeline?.timeline;
    return Array.isArray(timeline?.instructions) ? timeline : null;
  }

  function cursorValue(value) {
    if (typeof value !== 'string' || value.length === 0 || value.length > 4096 || /[\u0000-\u001f\u007f]/.test(value)) return null;
    return value;
  }

  function extractBookmarkPage(payload) {
    if (!record(payload) || (payload.errors !== undefined && (!Array.isArray(payload.errors) || payload.errors.length))) {
      return { posts: [], position: null, end: false, positionUnknown: true, error: 'source-error' };
    }
    const timeline = bookmarkTimeline(payload);
    if (!timeline) return { posts: [], position: null, end: false, positionUnknown: true, error: null };
    const posts = new Map();
    let position = null;
    let ended = false;
    let sawBottomCursor = false;
    function addCursor(content) {
      if (!record(content) || content.cursorType !== 'Bottom') return;
      sawBottomCursor = true;
      const value = cursorValue(content.value);
      if (value) position = value;
      else if (content.value === '') ended = true;
    }
    function addItem(itemContent) {
      const post = normalizeTweet(itemContent?.tweet_results?.result);
      if (post && !posts.has(post.id)) posts.set(post.id, post);
    }
    function addContent(content) {
      if (!record(content)) return;
      addCursor(content);
      if (content.entryType === 'TimelineTimelineModule' || Array.isArray(content.items)) return;
      addItem(content.itemContent);
    }
    for (const instruction of timeline.instructions) {
      if (!record(instruction)) continue;
      if (Array.isArray(instruction.entries)) for (const entry of instruction.entries) addContent(entry?.content);
      if (instruction.type === 'TimelineReplaceEntry') addContent(instruction.entry?.content);
      if (instruction.type === 'TimelineTerminateTimeline' && instruction.direction === 'Bottom') ended = true;
    }
    return {
      posts: [...posts.values()],
      position: ended ? null : position,
      end: ended,
      positionUnknown: !ended && !(sawBottomCursor && position),
      error: null,
    };
  }

  function extractBookmarkedPosts(payload) {
    return extractBookmarkPage(payload).posts;
  }

  function mutationSucceeded(operation, payload) {
    const field = operation === 'CreateBookmark' ? 'tweet_bookmark_put' : operation === 'DeleteBookmark' ? 'tweet_bookmark_delete' : null;
    return field !== null && record(payload) && record(payload.data)
      && (payload.errors === undefined || (Array.isArray(payload.errors) && payload.errors.length === 0))
      && payload.data[field] === 'Done';
  }

  globalThis.RevisitXData = Object.freeze({ extractBookmarkPage, extractBookmarkedPosts, parseOperation, mutationSucceeded });
})();
