(() => {
  const match = location.hash.match(/^#revisit-action=([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})$/i);
  if (window.top !== window || !match || globalThis.__revisitNativeActionInstalled) return;
  globalThis.__revisitNativeActionInstalled = true;
  const requestId = match[1];
  const mastodon = location.origin === 'https://m.cmx.im';
  const account = () => {
    if (mastodon) return globalThis.RevisitMastodonData.account();
    const link = document.querySelector('a[data-testid="AppTabBar_Profile_Link"]');
    return link ? new URL(link.href, location.origin).pathname.split('/').filter(Boolean)[0]?.toLowerCase() || '' : '';
  };
  chrome.runtime.sendMessage({ type: 'NATIVE_ACTION_READY', requestId }).then(async response => {
    if (!response?.ok) return;
    const task = response.data;
    if (!task || typeof task.accountUsername !== 'string' || !/^\d+$/.test(task.postId || '') || typeof task.bookmarked !== 'boolean' || (task.platform === 'mastodon') !== mastodon) return;
    if (!(await globalThis.RevisitPage.ensureCollectionAllowed())) {
      chrome.runtime.sendMessage({ type: 'NATIVE_ACTION_RESULT', requestId, ok: false, bookmarked: task.bookmarked, error: 'Revisit is not ready.' }).catch(() => {});
      return;
    }
    const expectedAccount = task.accountUsername.toLowerCase();
    let finished = false, clicking = false, observer;
    const finish = (ok, error) => {
      if (finished) return;
      finished = true;
      clearTimeout(timeout);
      observer?.disconnect();
      chrome.runtime.sendMessage({ type: 'NATIVE_ACTION_RESULT', requestId, ok, bookmarked: task.bookmarked, ...(error ? { error } : {}) }).catch(() => {});
    };
    const timeout = setTimeout(() => finish(false, 'The site did not confirm the bookmark change in time.'), 15000);
    const check = () => {
      if (finished || clicking) return;
      if (!globalThis.RevisitPage.isCollectionAllowed()) { finish(false, 'Revisit is not ready.'); return; }
      const currentAccount = account();
      if (currentAccount && currentAccount !== expectedAccount) { finish(false, 'ACCOUNT_MISMATCH'); return; }
      const statusId = location.pathname.match(mastodon ? /^\/@[^/]+\/(\d+)\/?$/ : /\/status\/(\d+)(?:\/|$)/)?.[1];
      if (statusId !== task.postId) { finish(false, 'The original post could not be opened.'); return; }
      if (!currentAccount) return;
      for (const article of document.querySelectorAll(mastodon ? '.status[data-id], .detailed-status__wrapper' : 'article[data-testid="tweet"]')) {
        let saved, unsaved;
        if (mastodon) {
          const id = article.getAttribute('data-id') || article.querySelector('a.detailed-status__datetime')?.getAttribute('href')?.match(/\/@[^/]+\/(\d+)(?:[/?#]|$)/)?.[1];
          if (id !== task.postId) continue;
          const button = article.querySelector('button.bookmark-icon');
          if (button?.classList.contains('active')) saved = button;
          else unsaved = button;
        } else {
          const timestamp = article.querySelector('a[href*="/status/"] time');
          const href = timestamp?.closest('a')?.getAttribute('href') || '';
          if (href.match(/\/status\/(\d+)(?:[/?#]|$)/)?.[1] !== task.postId) continue;
          saved = article.querySelector('[data-testid="removeBookmark"]');
          unsaved = article.querySelector('[data-testid="bookmark"]');
        }
        if (!saved && !unsaved) return;
        if ((task.bookmarked && saved) || (!task.bookmarked && unsaved)) { finish(true); return; }
        const button = task.bookmarked ? unsaved : saved;
        if (button.disabled || button.getAttribute('aria-disabled') === 'true') return;
        clearTimeout(timeout);
        clicking = true;
        const confirmation = globalThis.RevisitPage.waitForBookmarkChange(task.postId, task.bookmarked, expectedAccount);
        confirmation.then(() => {
          if (!globalThis.RevisitPage.isCollectionAllowed()) finish(false, 'Revisit is not ready.');
          else if (account() !== expectedAccount) finish(false, 'ACCOUNT_MISMATCH');
          else finish(true);
        }, () => finish(false, 'The site did not confirm the bookmark change.'));
        try { button.click(); } catch { finish(false, 'The site bookmark button could not be used.'); }
        return;
      }
    };
    observer = new MutationObserver(check);
    observer.observe(document, { childList: true, subtree: true, attributes: true, attributeFilter: ['data-testid', 'data-id', 'class', 'aria-disabled', 'disabled'] });
    check();
  }).catch(() => {});
})();
