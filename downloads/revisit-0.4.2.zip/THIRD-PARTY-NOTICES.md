# Third-party notices

Revisit is independent of X and Google. Product names and marks belong to their respective owners; their presence identifies compatibility and source, not endorsement.

X post text, account images and attached media remain the content of their respective owners. Access and display are subject to the user's authorization and X's applicable terms and display requirements. Do not treat a post's availability through an API as a license for unrelated reuse.

The local preview uses illustrative content and must be identified as a preview. Public store screenshots should show the real running extension with content the publisher is permitted to display.

## Tabler Icons

Bundled icon assets are derived from [Tabler Icons](https://github.com/tabler/tabler-icons), package `@tabler/icons` version 3.50.0. These are not represented as an official X icon distribution. Where the extension reuses a native icon already rendered on the user's X page, that rendering remains subject to X's terms and does not imply endorsement.

```text
MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

This document does not grant rights to third-party trademarks or assets.
