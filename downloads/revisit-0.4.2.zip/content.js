(() => {
  if (window.top !== window || globalThis.__revisitLoaded) return;
  globalThis.__revisitLoaded = true;
  const { t, locale } = globalThis.RevisitI18n;
  const mastodon = location.origin === 'https://m.cmx.im';
  let root, visitId, accountUsername, current, closed = false, loading = false, shown = false;
  let generation = 0, scheduled = false, visibilityObserver;
  let access;
  let accessRequest = 0;
  const iconUrl = name => chrome.runtime.getURL(`icons/${name}.svg`);
  const api = async (type, values = {}) => {
    const response = await chrome.runtime.sendMessage({ type, ...values });
    if (!response?.ok) throw new Error(response?.error?.message || t('error'));
    return response.data;
  };
  function element(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  }
  function icon(name, nativeTestId) {
    const native = nativeTestId && [...document.querySelectorAll(`[data-testid="${nativeTestId}"] svg`)].find(svg => !svg.closest('#revisit-root'));
    if (native) {
      const svg = native.cloneNode(true);
      svg.removeAttribute('class');
      svg.removeAttribute('style');
      svg.setAttribute('aria-hidden', 'true');
      svg.classList.add('rv-icon', 'rv-native-icon');
      return svg;
    }
    const img = element('img', `rv-icon rv-icon-${name}`);
    img.src = iconUrl(name);
    img.alt = '';
    img.setAttribute('aria-hidden', 'true');
    return img;
  }
  function button(name, label, className = '', nativeTestId) {
    const node = element('button', `rv-action ${className}`);
    node.type = 'button';
    node.title = label;
    node.setAttribute('aria-label', label);
    node.append(icon(name, nativeTestId));
    return node;
  }
  function link(href, className, text) {
    const node = element('a', className, text);
    node.href = href;
    node.target = '_blank';
    node.rel = 'noopener noreferrer';
    return node;
  }
  function safeURL(value) {
    try { const url = new URL(value); return ['https:', 'http:'].includes(url.protocol) ? url.href : null; } catch { return null; }
  }
  function syncTheme() {
    if (!root) return;
    const background = getComputedStyle(document.body).backgroundColor;
    const channels = background.match(/[\d.]+/g)?.slice(0, 3).map(Number);
    const isDark = channels && (channels[0] * .2126 + channels[1] * .7152 + channels[2] * .0722) < 128;
    root.dataset.theme = isDark ? 'dark' : 'light';
    if (channels) root.style.setProperty('--rv-background', background);
  }
  function showStatus(message, actionLabel, onAction) {
    visibilityObserver?.disconnect();
    current = null;
    root.querySelector('.rv-collection-guide').hidden = true;
    const body = element('div', 'rv-status');
    body.setAttribute('role', 'status');
    body.append(element('span', '', message));
    if (actionLabel) {
      const action = element('button', 'rv-text-button', actionLabel);
      action.type = 'button';
      action.addEventListener('click', onAction);
      body.append(action);
    }
    root.querySelector('.rv-body').replaceChildren(body);
  }
  function renderCollectionGuide(data) {
    const guide = root.querySelector('.rv-collection-guide');
    guide.hidden = data.showCollectionGuide !== true;
    if (guide.hidden || guide.children.length) return;
    const text = element('p', '', t('oldBookmarksGuide'));
    const actions = element('div', 'rv-guide-actions');
    const open = element('button', 'rv-text-button', t('bookmarksGuideAction'));
    open.type = 'button';
    open.addEventListener('click', openBookmarks);
    const dismiss = element('button', 'rv-text-button', t('dismissCollectionGuide'));
    dismiss.type = 'button';
    const selectedGeneration = generation;
    const selectedAccount = accountUsername;
    dismiss.addEventListener('click', async () => {
      if (loading || dismiss.disabled) return;
      dismiss.disabled = true;
      try {
        await api('DISMISS_COLLECTION_GUIDE', { accountUsername: selectedAccount, visitId });
        if (selectedGeneration !== generation) return;
        if (current) current.showCollectionGuide = false;
        guide.hidden = true;
      } catch (error) {
        if (selectedGeneration === generation) root.querySelector('.rv-feedback').textContent = error.message;
      } finally { dismiss.disabled = false; }
    });
    actions.append(open, dismiss);
    guide.append(text, actions);
  }
  function appendText(container, post) {
    const urls = new Map((post.urls || []).map(item => [item.url, item]));
    const pattern = mastodon ? /(https?:\/\/[^\s]+|@[A-Za-z0-9_.-]+(?:@[A-Za-z0-9.-]+(?::[0-9]+)?)?|#[\p{L}\p{N}_]+)/gu : /(https?:\/\/[^\s]+|@[A-Za-z0-9_]{1,15}|#[\p{L}\p{N}_]+)/gu;
    let last = 0;
    for (const match of post.text.matchAll(pattern)) {
      container.append(document.createTextNode(post.text.slice(last, match.index)));
      const value = match[0], entity = urls.get(value);
      let href;
      if (value.startsWith('@')) href = mastodon ? `https://m.cmx.im/${value}` : `https://x.com/${value.slice(1)}`;
      else if (value.startsWith('#')) href = mastodon ? `https://m.cmx.im/tags/${encodeURIComponent(value.slice(1))}` : `https://x.com/search?q=${encodeURIComponent(value)}`;
      else href = safeURL(value);
      if (href) container.append(link(href, 'rv-inline-link', entity?.displayUrl || value));
      else container.append(document.createTextNode(value));
      last = match.index + value.length;
    }
    container.append(document.createTextNode(post.text.slice(last)));
  }
  function observeExposure(target, selectedGeneration) {
    visibilityObserver?.disconnect();
    visibilityObserver = new IntersectionObserver(entries => {
      if (selectedGeneration !== generation || shown || !current || document.visibilityState !== 'visible') return;
      if (!entries.some(entry => entry.isIntersecting && entry.intersectionRatio >= .75)) return;
      shown = true;
      api('MARK_SHOWN', { visitId, postId: current.post.id, accountId: current.accountId }).catch(() => { shown = false; });
    }, { threshold: [.75] });
    visibilityObserver.observe(target);
  }
  function renderPost(data) {
    current = data;
    const post = data.post;
    const original = mastodon ? post.url : `https://x.com/${encodeURIComponent(post.author.username)}/status/${post.id}`;
    const article = element('article', 'rv-post');
    article.tabIndex = 0;
    article.setAttribute('aria-label', t('viewOnX'));
    const openOriginal = event => {
      if (event.defaultPrevented || event.composedPath().some(node => node instanceof Element && node.matches('a, button, summary')) || window.getSelection()?.isCollapsed === false) return;
      if (event.type === 'keydown') {
        if (event.target !== article || event.key !== 'Enter') return;
      } else if (event.button !== 0 && event.button !== 1) return;
      event.preventDefault();
      if (event.ctrlKey || event.metaKey || event.button === 1) window.open(original, '_blank', 'noopener,noreferrer');
      else location.assign(original);
    };
    article.addEventListener('click', openOriginal);
    article.addEventListener('auxclick', openOriginal);
    article.addEventListener('keydown', openOriginal);
    const author = element('div', 'rv-author');
    const profile = mastodon ? post.author.url : `https://x.com/${encodeURIComponent(post.author.username)}`;
    const avatarLink = link(profile, 'rv-avatar-link');
    const avatar = element('img', 'rv-avatar');
    avatar.alt = '';
    avatar.referrerPolicy = 'no-referrer';
    const avatarURLs = [...new Set([post.author.avatar, ...(mastodon ? [post.author.avatarFallback] : [])].map(safeURL).filter(Boolean))];
    const loadAvatar = () => {
      const url = avatarURLs.shift();
      if (url) avatar.src = url;
      else {
        avatarLink.classList.toggle('rv-avatar-missing', true);
        avatarLink.replaceChildren(icon('user'));
      }
    };
    avatar.addEventListener('error', loadAvatar);
    avatarLink.append(avatar);
    loadAvatar();
    author.append(avatarLink);
    const details = element('div', 'rv-author-details');
    details.append(link(profile, 'rv-name', post.author.name), link(profile, 'rv-handle', `@${post.author.username}`));
    if (post.createdAt) {
      const date = new Date(post.createdAt);
      if (!Number.isNaN(date.valueOf())) {
        details.append(element('span', 'rv-dot', '·'));
        const timestamp = link(original, 'rv-date');
        const time = element('time', '', new Intl.DateTimeFormat(locale, { year: 'numeric', month: 'short', day: 'numeric' }).format(date));
        time.dateTime = date.toISOString();
        timestamp.append(time);
        details.append(timestamp);
      }
    }
    author.append(details);
    const source = link(original, 'rv-source');
    source.title = t('viewOnX');
    source.setAttribute('aria-label', t('viewOnX'));
    source.append(icon(mastodon ? 'brand-mastodon' : 'brand-x'));
    author.append(source);
    article.append(author);
    const content = element('div', 'rv-post-content');
    const text = element('div', 'rv-post-text');
    if (!mastodon) text.setAttribute('data-testid', 'tweetText');
    if (post.lang) text.setAttribute('lang', post.lang);
    text.dir = 'auto';
    appendText(text, post);
    content.append(text);
    let postBody = article;
    if (mastodon && (post.spoilerText || post.sensitive)) {
      postBody = element('details', 'rv-warning');
      postBody.append(element('summary', '', post.spoilerText || t('sensitiveContent')));
      article.append(postBody);
    }
    postBody.append(content);
    if (post.media?.length) {
      const media = element('div', 'rv-media');
      for (const item of post.media.slice(0, 4)) {
        const imageURL = safeURL(item.type === 'photo' ? item.url : item.previewUrl);
        if (!imageURL) continue;
        const entry = link(original, 'rv-media-link');
        const image = element('img', 'rv-media-image');
        image.src = imageURL;
        image.alt = item.altText || '';
        image.referrerPolicy = 'no-referrer';
        image.loading = 'lazy';
        entry.append(image);
        if (item.type !== 'photo') { entry.title = t('viewOnX'); entry.append(icon('player-play')); }
        media.append(entry);
      }
      postBody.append(media);
    }
    const actions = element('div', 'rv-actions');
    const compactNumber = new Intl.NumberFormat('en', { notation: 'compact', maximumFractionDigits: 1 });
    function addCount(action, key) {
      const count = post.metrics?.[key];
      if (!Number.isSafeInteger(count) || count <= 0) return;
      const label = `${action.title} · ${new Intl.NumberFormat(locale).format(count)}`;
      action.title = label;
      action.setAttribute('aria-label', label);
      action.append(element('span', 'rv-count', compactNumber.format(count)));
    }
    const reply = link(mastodon ? original : `https://twitter.com/intent/tweet?in_reply_to=${post.id}`, 'rv-action rv-reply');
    reply.title = t('reply'); reply.setAttribute('aria-label', t('reply'));
    reply.append(icon('reply', 'reply'));
    addCount(reply, 'replies');
    const repost = link(mastodon ? original : `https://twitter.com/intent/retweet?tweet_id=${post.id}`, 'rv-action rv-repost');
    repost.title = t('repost'); repost.setAttribute('aria-label', t('repost'));
    repost.append(icon('repost', 'retweet'));
    addCount(repost, 'reposts');
    const likes = link(original, 'rv-action rv-likes');
    likes.title = t('likesOnX'); likes.setAttribute('aria-label', t('likesOnX'));
    likes.append(icon('heart', 'like'));
    addCount(likes, 'likes');
    const views = link(`${original}/analytics`, 'rv-action rv-views');
    views.title = t('views'); views.setAttribute('aria-label', t('views'));
    views.append(icon('chart-bar'));
    addCount(views, 'views');
    const bookmark = button('bookmark-filled', t('removeBookmark'), 'rv-bookmark');
    function updateBookmark(bookmarked) {
      if (!current) return;
      current.bookmarked = bookmarked;
      bookmark.replaceChildren(icon(bookmarked ? 'bookmark-filled' : 'bookmark', bookmarked ? 'removeBookmark' : 'bookmark'));
      bookmark.classList.toggle('rv-saved', bookmarked);
      bookmark.setAttribute('aria-pressed', String(bookmarked));
      bookmark.setAttribute('aria-label', t(bookmarked ? 'removeBookmark' : 'addBookmark'));
      bookmark.title = t(bookmarked ? 'removeBookmark' : 'addBookmark');
    }
    updateBookmark(data.bookmarked !== false);
    bookmark.addEventListener('click', async event => {
      if (!event.isTrusted) return;
      if (loading) return;
      bookmark.disabled = true;
      const selectedGeneration = generation;
      const selectedAccount = accountUsername;
      try {
        const changed = await globalThis.RevisitPage.setBookmark(post.id, !current.bookmarked, selectedAccount);
        if (selectedGeneration !== generation || pageAccount().toLowerCase() !== selectedAccount.toLowerCase()) return;
        const result = await api('CONFIRM_BOOKMARK_CHANGE', { postId: post.id, accountUsername: selectedAccount, bookmarked: changed.bookmarked });
        if (selectedGeneration === generation) { updateBookmark(result.bookmarked); root.querySelector('.rv-feedback').textContent = ''; }
      } catch (error) { if (selectedGeneration === generation) root.querySelector('.rv-feedback').textContent = error.message; }
      finally { bookmark.disabled = false; }
    });
    const share = link(original, 'rv-action rv-share');
    share.title = t('shareOnX'); share.setAttribute('aria-label', t('shareOnX'));
    share.append(icon('share'));
    const tail = element('div', 'rv-action-tail');
    tail.append(bookmark, share);
    actions.append(reply, repost, likes);
    if (!mastodon) actions.append(views);
    actions.append(tail);
    article.append(actions);
    root.querySelector('.rv-body').replaceChildren(article);
    observeExposure(author, generation);
  }
  async function load({ refresh = false } = {}) {
    if (loading || closed || !root || document.visibilityState !== 'visible') return;
    if (!access?.collectionAllowed) {
      showStatus(t(access?.vaultStatus === 'migration-required' ? 'vaultMigrationHome' : 'vaultSetupHome'), t('vaultOpenSettings'), () => api('OPEN_SETTINGS').catch(() => {}));
      return;
    }
    loading = true;
    const selectedGeneration = generation;
    const previous = current;
    const nextVisitId = refresh ? crypto.randomUUID() : visitId;
    const keepCurrent = refresh && previous;
    const refreshControl = root.querySelector('.rv-refresh');
    if (refreshControl) refreshControl.disabled = true;
    if (!keepCurrent) showStatus(t('loading'));
    try {
      const data = await api('GET_BOOKMARK', {
        visitId: nextVisitId,
        accountUsername,
        ...(refresh && previous ? { excludePostId: previous.post.id } : {}),
      });
      if (selectedGeneration !== generation || !root || closed) {
        if (data.status === 'ready') api('RELEASE_VISIT', { visitId: nextVisitId }).catch(() => {});
        return;
      }
      if (data.status === 'ready' && document.visibilityState !== 'visible' && !refresh) {
        await api('RELEASE_VISIT', { visitId: nextVisitId });
        showStatus(t('loading'));
      }
      else if (data.status === 'ready') {
        visitId = nextVisitId;
        renderCollectionGuide(data);
        if (refresh && previous?.post.id === data.post.id) {
          root.querySelector('.rv-feedback').textContent = t('noOtherBookmarks');
          observeExposure(root.querySelector('.rv-author'), generation);
          return;
        }
        shown = false;
        root.querySelector('.rv-feedback').textContent = '';
        renderPost(data);
      }
      else if (data.status === 'disabled') root.hidden = true;
      else if (data.status === 'migration-required' || data.status === 'setup-required') {
        current = null;
        showStatus(t(data.status === 'migration-required' ? 'vaultMigrationHome' : 'vaultSetupHome'), t('vaultOpenSettings'), () => api('OPEN_SETTINGS').catch(() => {}));
      }
      else if (data.status === 'empty') showStatus(t('collectionHint'), t('openBookmarks'), openBookmarks);
      else if (data.status === 'waiting') {
        if (refresh && previous && previous.bookmarked !== false) root.querySelector('.rv-feedback').textContent = t('noOtherBookmarks');
        else {
          showStatus(t('loading'));
          setTimeout(() => { if (selectedGeneration === generation && root?.isConnected) load(); }, 1500);
        }
      }
      else if (data.status === 'account-mismatch') showStatus(t('accountMismatch'));
      else showStatus(t('collectionHint'), t('openBookmarks'), openBookmarks);
    } catch (error) {
      if (selectedGeneration === generation && root) {
        if (refresh && previous) root.querySelector('.rv-feedback').textContent = error.message;
        else showStatus(error.message, t('retry'), load);
      }
    } finally {
      if (selectedGeneration === generation) {
        loading = false;
        const control = root?.querySelector('.rv-refresh');
        if (control) control.disabled = false;
      }
    }
  }
  function refreshPost() {
    if (loading || closed || !root || root.querySelector('.rv-bookmark')?.disabled) return;
    return load({ refresh: true });
  }
  function openBookmarks() { api('OPEN_BOOKMARKS').catch(() => {}); }
  function reset() {
    generation++;
    if (visitId) api('RELEASE_VISIT', { visitId }).catch(() => {});
    visibilityObserver?.disconnect();
    root?.remove();
    root = null; current = null; visitId = null; shown = false; closed = false; loading = false;
  }
  function pageAccount() {
    if (mastodon) return globalThis.RevisitMastodonData.account();
    const anchor = document.querySelector('a[data-testid="AppTabBar_Profile_Link"]');
    return anchor ? new URL(anchor.href, location.origin).pathname.split('/').filter(Boolean)[0].toLowerCase() : '';
  }
  function check() {
    scheduled = false;
    if (!/^\/home\/?$/.test(location.pathname)) { if (visitId) reset(); return; }
    if (!access || !access.enabled) { if (root) reset(); return; }
    const account = access.collectionAllowed ? pageAccount() : '';
    if (accountUsername !== account) { reset(); accountUsername = account; }
    const column = document.querySelector(mastodon ? 'main .column' : '[data-testid="primaryColumn"]');
    if (!column || closed) return;
    let insertion;
    if (mastodon) insertion = column.querySelector('.scrollable');
    else {
      const tabs = column.querySelector('[role="tablist"]');
      if (!tabs) return;
      insertion = tabs.parentElement;
      while (insertion && insertion !== column && getComputedStyle(insertion).position !== 'sticky') insertion = insertion.parentElement;
    }
    if (!insertion || insertion === column) { root?.remove(); return; }
    const place = () => {
      if (mastodon) {
        if (root.nextElementSibling !== insertion) insertion.before(root);
      } else if (insertion.nextElementSibling !== root) insertion.after(root);
    };
    if (!visitId) visitId = crypto.randomUUID();
    if (root?.isConnected) {
      place();
      syncTheme();
      return;
    }
    root = element('section', 'rv-root');
    root.id = 'revisit-root';
    if (mastodon) root.dataset.platform = 'mastodon';
    root.setAttribute('aria-label', 'Revisit');
    const header = element('div', 'rv-header');
    header.append(icon('bookmark'), element('span', 'rv-brand', 'Revisit'));
    const refresh = button('refresh', t('refreshBookmark'), 'rv-refresh');
    refresh.addEventListener('click', refreshPost);
    const close = button('close', t('close'), 'rv-close');
    close.addEventListener('click', () => { closed = true; root.remove(); visibilityObserver?.disconnect(); api('RELEASE_VISIT', { visitId }).catch(() => {}); });
    header.append(refresh, close);
    const feedback = element('div', 'rv-feedback'); feedback.setAttribute('role', 'status');
    const guide = element('div', 'rv-collection-guide');
    guide.hidden = true;
    root.append(header, guide, element('div', 'rv-body'), feedback);
    place();
    syncTheme();
    if (current) { renderCollectionGuide(current); renderPost(current); } else load();
  }
  function schedule() { if (!scheduled) { scheduled = true; requestAnimationFrame(check); } }
  async function refreshAccess() {
    const request = ++accessRequest;
    const state = await api('GET_STATE');
    if (request !== accessRequest) return;
    if (!state.collectionAllowed && state.vaultStatus === 'unlocked') state.vaultStatus = 'setup-required';
    const changed = access?.collectionAllowed !== state.collectionAllowed || access?.vaultStatus !== state.vaultStatus;
    access = state;
    if (changed || !state.enabled) { reset(); accountUsername = ''; }
    if (root && state.collectionAllowed && pageAccount() !== accountUsername) { reset(); accountUsername = ''; }
    if (root) root.hidden = false;
    schedule();
  }
  new MutationObserver(schedule).observe(document.body, { childList: true, subtree: true });
  new MutationObserver(syncTheme).observe(document.body, { attributes: true, attributeFilter: ['class', 'style'] });
  window.addEventListener('popstate', schedule);
  window.addEventListener('pagehide', () => { if (visitId) api('RELEASE_VISIT', { visitId }).catch(() => {}); });
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') {
      if (current && root?.isConnected) observeExposure(root.querySelector('.rv-author'), generation);
      else load();
      schedule();
    } else if (current && !shown) {
      api('RELEASE_VISIT', { visitId }).catch(() => {});
      current = null;
      visibilityObserver?.disconnect();
      if (root) showStatus(t('loading'));
    }
  });
  chrome.runtime.onMessage.addListener(message => {
    if (message.type === 'STATE_CHANGED') {
      if (message.collectionAllowed === false) {
        accessRequest++;
        reset();
        accountUsername = '';
        access = { enabled: access?.enabled ?? true, collectionAllowed: false, vaultStatus: 'setup-required' };
        schedule();
      } else if (root) root.hidden = true;
      refreshAccess().catch(() => { reset(); access = undefined; });
    }
  });
  refreshAccess().catch(() => {});
  schedule();
})();
