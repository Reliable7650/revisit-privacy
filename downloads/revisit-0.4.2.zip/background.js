import { createBackend } from './lib/backend.js';
import { createHistoryReader } from './lib/history-reader.js';
import { createNativeActionExecutor } from './lib/native-action.js';

const nativeActions = createNativeActionExecutor({ chrome });
const backend = createBackend({ chrome, executeNativeAction: nativeActions.execute });
const historyReader = createHistoryReader({ chrome, backend });
const contentMessages = new Set(['GET_STATE', 'GET_BOOKMARK', 'MARK_SHOWN', 'DISMISS_COLLECTION_GUIDE', 'NATIVE_BOOKMARK_ACTION', 'CONFIRM_BOOKMARK_CHANGE', 'IMPORT_BOOKMARKS', 'SAVE_OBSERVED_BOOKMARK', 'REGISTER_ACCOUNT', 'RELEASE_VISIT', 'OPEN_SETTINGS', 'OPEN_BOOKMARKS']);
const managementMessages = new Set(['GET_STATE', 'ACCEPT_COLLECTION', 'MIGRATE_LOCAL_DATA', 'CLEAR_DATA', 'SET_ENABLED', 'SET_EXPANDED_COLLECTION', 'SET_HISTORY_COLLECTION', 'START_HISTORY', 'STOP_HISTORY', 'OPEN_BOOKMARKS']);

async function managementContext(message) {
  const [tabs, activeTabs] = await Promise.all([chrome.tabs.query({}), chrome.tabs.query({ active: true, currentWindow: true })]);
  const supported = tabs.filter(tab => /^https:\/\/(?:x\.com|m\.cmx\.im)\//.test(tab.url || ''));
  const tab = supported.find(tab => tab.id === activeTabs[0]?.id) || supported.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0))[0];
  const platform = message.platform === 'mastodon' || message.platform === 'x' ? message.platform : tab ? new URL(tab.url).hostname === 'm.cmx.im' ? 'mastodon' : 'x' : undefined;
  let accountUsername;
  if (message.type === 'GET_STATE' && tab) {
    accountUsername = '';
    try {
      const response = await chrome.tabs.sendMessage(tab.id, { type: 'GET_PAGE_ACCOUNT' });
      accountUsername = response?.accountUsername || '';
    } catch {}
  }
  return { platform, ...(accountUsername === undefined ? {} : { accountUsername }) };
}

chrome.runtime.onInstalled?.addListener(({ reason }) => {
  if (reason === 'install') chrome.tabs.create({ url: chrome.runtime.getURL('welcome.html') }).catch(() => {});
});

async function openHistoryPageForRecovery() {
  const [active] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (active?.url && /^https:\/\/x\.com\/i\/(?:history|bookmarks)(?:\/|$)/.test(active.url)) return;
  await chrome.tabs.create({ url: 'https://x.com/i/history' });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (sender.id !== chrome.runtime.id || !message || typeof message.type !== 'string') return false;
  if (!sender.url) return false;
  const url = new URL(sender.url);
  const ownPage = url.protocol === 'chrome-extension:' && url.hostname === chrome.runtime.id && ['/popup.html', '/welcome.html'].includes(url.pathname);
  const xPage = url.origin === 'https://x.com' && sender.frameId === 0;
  const mastodonPage = url.origin === 'https://m.cmx.im' && sender.frameId === 0;
  if (message.type === 'NATIVE_ACTION_READY' || message.type === 'NATIVE_ACTION_RESULT') {
    nativeActions.handleHelperMessage(message, sender).then(
      data => sendResponse({ ok: true, data }),
      error => sendResponse({ ok: false, error: { code: error.code || 'NATIVE_ACTION_FAILED', message: error.message } }),
    );
    return true;
  }
  const collectionPage = xPage ? /^\/i\/(?:bookmarks(?:\/|$)|history\/?$)/.test(url.pathname) : mastodonPage && /^\/bookmarks\/?$/.test(url.pathname);
  const requiresCollectionPage = message.type === 'IMPORT_BOOKMARKS';
  const homeAction = !['NATIVE_BOOKMARK_ACTION', 'DISMISS_COLLECTION_GUIDE'].includes(message.type) || /^\/home\/?$/.test(url.pathname);
  const requestedAccount = message.accountUsername || message.accountId;
  const matchingPlatform = !requestedAccount || typeof requestedAccount === 'string' && (mastodonPage ? requestedAccount.startsWith('m.cmx.im:') : !requestedAccount.startsWith('m.cmx.im:'));
  if (!(ownPage && managementMessages.has(message.type)) && !((xPage || mastodonPage) && matchingPlatform && homeAction && contentMessages.has(message.type) && (!requiresCollectionPage || collectionPage))) {
    sendResponse({ ok: false, error: { code: 'FORBIDDEN', message: 'This page cannot make that request.' } });
    return false;
  }
  if (message.type === 'CLEAR_DATA') {
    nativeActions.cancelAll();
    historyReader.stop().catch(() => {})
      .then(() => backend.handle(message, { tabId: sender.tab?.id, source: 'management' }))
      .then(
        data => sendResponse({ ok: true, data }),
        error => sendResponse({ ok: false, error: { code: error.code || 'INTERNAL_ERROR', message: error.message } }),
      );
    return true;
  }
  if (message.type === 'START_HISTORY') {
    if (message.accountUsername?.startsWith('m.cmx.im:')) {
      sendResponse({ ok: false, error: { code: 'INVALID_ACCOUNT', message: 'Open Mastodon bookmarks and scroll down to load older bookmarks.' } });
      return false;
    }
    if (message.consent !== true) {
      sendResponse({ ok: false, error: { code: 'HISTORY_CONSENT_REQUIRED', message: 'Confirm the X web-interface warning first.' } });
      return false;
    }
    backend.handle({ type: 'SET_HISTORY_COLLECTION', enabled: true }, { tabId: sender.tab?.id, source: 'management' })
      .then(() => historyReader.start({ accountUsername: message.accountUsername, consent: true }))
      .then(async data => {
        await openHistoryPageForRecovery().catch(() => {});
        return data;
      })
      .then(data => sendResponse({ ok: true, data }), error => sendResponse({ ok: false, error: { code: error.code || 'HISTORY_START_FAILED', message: error.message } }));
    return true;
  }
  if (message.type === 'STOP_HISTORY') {
    historyReader.stop().then(
      data => sendResponse({ ok: true, data }),
      error => sendResponse({ ok: false, error: { code: error.code || 'HISTORY_STOP_FAILED', message: error.message } }),
    );
    return true;
  }
  if (message.type === 'SET_HISTORY_COLLECTION' && message.enabled === false) {
    historyReader.stop()
      .then(() => backend.handle(message, { tabId: sender.tab?.id, source: 'management' }))
      .then(
        data => sendResponse({ ok: true, data }),
        error => sendResponse({ ok: false, error: { code: error.code || 'INTERNAL_ERROR', message: error.message } }),
      );
    return true;
  }
  (async () => {
    const context = ownPage && ['GET_STATE', 'OPEN_BOOKMARKS'].includes(message.type) ? await managementContext(message) : { platform: mastodonPage ? 'mastodon' : xPage ? 'x' : undefined };
    return backend.handle(message, { tabId: sender.tab?.id, source: ownPage ? 'management' : 'content', ...context });
  })().then(
    data => sendResponse({ ok: true, data: message.type === 'GET_STATE' ? { ...data, historyRuntime: historyReader.summary() } : data }),
    error => sendResponse({ ok: false, error: { code: error.code || 'INTERNAL_ERROR', message: error.code ? error.message : 'The extension could not complete this request.' } }),
  );
  return true;
});

chrome.tabs.onRemoved.addListener(tabId => {
  nativeActions.releaseTab(tabId);
  backend.releaseTab(tabId).catch(() => {});
});
