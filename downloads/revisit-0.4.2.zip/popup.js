(() => {
  const { locale, t } = globalThis.RevisitI18n;
  document.documentElement.lang = locale;
  document.querySelectorAll('[data-i18n]').forEach((element) => {
    element.textContent = t(element.dataset.i18n);
  });
  const element = (id) => document.getElementById(id);
  let state;
  let busy = false;
  let refreshing;
  let refreshVersion = 0;
  let refreshTimer;

  async function send(type, values = {}) {
    const response = await chrome.runtime.sendMessage({ type, ...values });
    if (!response?.ok) throw Object.assign(new Error(response?.error?.message || t('operationFailed')), { code: response?.error?.code });
    return response.data;
  }

  function status(message = '', isError = false) {
    element('status').textContent = message;
    element('status').dataset.error = String(isError);
  }

  function render() {
    if (!state) return;
    const mastodon = state.platform === 'mastodon';
    const unlocked = state.vaultStatus === 'unlocked' && state.collectionAllowed === true;
    const migration = state.vaultStatus === 'migration-required';
    element('vault-panel').hidden = unlocked;
    element('unlocked-controls').hidden = !unlocked;
    element('vault-title').textContent = t(migration ? 'vaultMigrationTitle' : 'vaultSetupTitle');
    element('vault-explanation').textContent = t(state.vaultError ? 'vaultCorrupt' : migration ? 'vaultMigrationNotice' : 'vaultSetupNotice');
    element('vault-form').hidden = Boolean(state.vaultError);
    element('vault-consent').hidden = migration;
    element('vault-password-row').hidden = !migration;
    element('vault-password').required = migration;
    element('vault-submit').textContent = t(migration ? 'vaultMigrate' : 'vaultAgree');
    const username = state.user?.username?.replace(/^m\.cmx\.im:/, '');
    const displayUsername = username ? mastodon ? username : username.charAt(0).toUpperCase() + username.slice(1) : '';
    element('account-platform-icon').hidden = mastodon;
    element('author-link').hidden = !username;
    element('account-name').textContent = displayUsername ? `@${displayUsername}` : '';
    if (username) {
      element('author-link').href = mastodon ? `https://m.cmx.im/@${encodeURIComponent(username)}` : `https://x.com/${encodeURIComponent(username)}`;
      element('author-link').title = t('openAuthorProfile', { username: displayUsername });
      element('author-link').setAttribute('aria-label', t('openAuthorProfile', { username: displayUsername }));
    }
    element('enabled').checked = state.enabled;
    element('expanded-collection').checked = state.expandedCollectionAllowed === true;
    const runtime = state.historyRuntime || {};
    const stored = state.history || {};
    const history = mastodon ? {} : runtime.status && runtime.status !== 'idle'
      ? runtime
      : stored.status && stored.status !== 'idle'
        ? { ...stored, status: stored.status === 'reading' ? 'paused' : stored.status, addedCount: stored.lastAdded || 0 }
        : runtime;
    const historyRunning = history.status === 'starting' || history.status === 'reading';
    element('history-notice').textContent = t(mastodon ? 'oldBookmarksGuide' : 'historyNotice');
    element('find-old-bookmarks').textContent = t(mastodon ? 'bookmarksGuideAction' : 'findOldBookmarks');
    element('find-old-bookmarks').hidden = historyRunning;
    element('stop-history').hidden = !historyRunning;
    const historyAdded = history.addedCount || history.lastAdded || 0;
    element('history-status').textContent = history.status === 'paused' && historyAdded === 0
      ? t('historyNoNew')
      : history.status
        ? t('historyStatus', {
          status: t(`history_${history.status.replaceAll('-', '_')}`),
          added: new Intl.NumberFormat(locale).format(historyAdded),
        })
        : '';
    element('bookmark-count').textContent = t('bookmarkCount', {
      count: new Intl.NumberFormat(locale).format(state.bookmarkCount || 0),
    });
    element('last-collected').textContent = state.syncedAt
      ? t('lastCollected', { date: new Intl.DateTimeFormat(locale, { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(state.syncedAt)) })
      : t('neverCollected');
    document.querySelectorAll('button, input').forEach((control) => {
      control.disabled = busy;
    });
    element('find-old-bookmarks').disabled = busy || (!mastodon && !username);
    element('stop-history').disabled = busy;
    element('vault-password').disabled = busy || !migration || Boolean(state.vaultError);
  }

  async function refresh(force = false) {
    if (force) { refreshVersion++; refreshing = undefined; }
    if (refreshing) return refreshing;
    const version = refreshVersion;
    const pending = send('GET_STATE').then((data) => {
      if (version !== refreshVersion) return;
      state = data;
      render();
    }).finally(() => { if (refreshing === pending) refreshing = undefined; });
    refreshing = pending;
    return pending;
  }

  async function run(type, values, successKey) {
    if (busy) return;
    busy = true;
    status(t('working'));
    render();
    try {
      await send(type, values);
      await refresh(true);
      status(successKey ? t(successKey) : '');
    } catch (error) {
      const vaultErrors = { INVALID_PASSWORD: 'vaultPasswordLength', VAULT_UNLOCK_FAILED: 'vaultWrongPassword', VAULT_CORRUPT: 'vaultCorrupt', VAULT_MIGRATION_FAILED: 'vaultCorrupt' };
      status(`${t('operationFailed')} ${vaultErrors[error.code] ? t(vaultErrors[error.code]) : error.message}`, true);
      await refresh().catch(() => {});
    } finally {
      busy = false;
      render();
    }
  }

  element('open-bookmarks').addEventListener('click', () => run('OPEN_BOOKMARKS', { platform: state?.platform || 'x' }));
  element('clear-data').addEventListener('click', () => {
    element('clear-confirmation').hidden = false;
    element('clear-data').hidden = true;
  });
  element('cancel-clear').addEventListener('click', () => {
    element('clear-confirmation').hidden = true;
    element('clear-data').hidden = false;
  });
  element('confirm-clear').addEventListener('click', () => {
    element('clear-confirmation').hidden = true;
    element('clear-data').hidden = false;
    run('CLEAR_DATA', {}, 'dataCleared');
  });
  element('vault-form').addEventListener('submit', async event => {
    event.preventDefault();
    if (busy) return;
    const migration = state.vaultStatus === 'migration-required';
    try {
      await run(migration ? 'MIGRATE_LOCAL_DATA' : 'ACCEPT_COLLECTION', migration ? { password: element('vault-password').value } : {});
    } finally {
      element('vault-password').value = '';
    }
  });
  element('enabled').addEventListener('change', () => {
    const enabled = element('enabled').checked;
    run('SET_ENABLED', { enabled }, enabled ? 'enabled' : 'disabled');
  });

  element('expanded-collection').addEventListener('change', () => {
    run('SET_EXPANDED_COLLECTION', { enabled: element('expanded-collection').checked });
  });

  function startHistory() {
    if (state?.platform === 'mastodon') return;
    if (!state?.user?.username) {
      status(t('historyAccountRequired'), true);
      return;
    }
    run('START_HISTORY', { accountUsername: state.user.username, consent: true }, 'historyStarted');
  }

  element('find-old-bookmarks').addEventListener('click', () => {
    if (state?.platform === 'mastodon') {
      run('OPEN_BOOKMARKS', { platform: 'mastodon' });
      return;
    }
    if (state?.historyCollectionAllowed === true) {
      startHistory();
      return;
    }
    element('history-consent').showModal?.();
  });
  element('history-cancel').addEventListener('click', () => {
    element('history-consent').close?.();
  });
  element('history-agree').addEventListener('click', () => {
    element('history-consent').close?.();
    startHistory();
  });
  element('stop-history').addEventListener('click', () => {
    run('STOP_HISTORY', {}, 'historyStopped');
  });

  function scheduleRefresh() {
    clearTimeout(refreshTimer);
    refreshTimer = setTimeout(() => {
      refresh().catch((error) => status(`${t('operationFailed')} ${error.message}`, true));
    }, 80);
  }
  chrome.storage.onChanged.addListener((_, area) => {
    if (area === 'local') scheduleRefresh();
  });
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === 'STATE_CHANGED') {
      if (message.collectionAllowed === false) {
        refreshVersion++;
        refreshing = undefined;
        state = { enabled: true, vaultStatus: 'setup-required', collectionAllowed: false };
        element('vault-password').value = '';
        render();
      }
      scheduleRefresh();
    }
  });
  refresh().catch((error) => status(`${t('operationFailed')} ${error.message}`, true));
})();
