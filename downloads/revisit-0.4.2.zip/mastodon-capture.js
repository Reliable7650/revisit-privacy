(() => {
  if (window.top !== window) return;
  const channel = crypto.randomUUID();
  const waiting = new Map();
  const seen = new Map();
  const removed = new Set();
  const enableWaiters = new Set();
  let timer, previousAccount = '', registeredAccount = '', domAllowed = true, accountEpoch = 0;
  let expandedAllowed = false;
  let allowed = false, enabledAck = false, enableRequest, permissionVersion = 0, permissionPromise;
  const { account, isBookmarksPage: bookmarksPage, postFromElement } = globalThis.RevisitMastodonData;
  const send = async (type, values = {}) => {
    const response = await chrome.runtime.sendMessage({ type, ...values });
    if (!response?.ok) throw new Error(response?.error?.message || 'Local storage could not be updated.');
    return response.data;
  };
  const bridge = (type, values = {}) => window.postMessage({ source: 'revisit-content', channel, type, ...values }, location.origin);
  function initialize() {
    bridge('INIT');
    enabledAck = false; enableRequest = undefined;
    if (allowed) enableBridge(); else bridge('DISABLE');
  }
  function rejectWaiting() {
    for (const [id, request] of waiting) {
      clearTimeout(request.timer); waiting.delete(id);
      request.reject(new Error(globalThis.RevisitI18n?.t('actionFailed') || 'The bookmark change could not be confirmed.'));
    }
  }
  function settleEnableWaiters(value) {
    for (const request of enableWaiters) { clearTimeout(request.timer); request.resolve(value); }
    enableWaiters.clear();
  }
  function enableBridge() {
    if (!enableRequest) enableRequest = crypto.randomUUID();
    bridge('ENABLE', { requestId: enableRequest });
  }
  function applyPermission(next) {
    if (!next) {
      if (allowed) domAllowed = false;
      allowed = false; enabledAck = false; enableRequest = undefined; previousAccount = ''; accountEpoch++;
      clearTimeout(timer); collectionObserver.disconnect(); seen.clear(); removed.clear(); rejectWaiting();
      bridge('DISABLE'); settleEnableWaiters(false);
    } else if (!allowed) {
      allowed = true;
      collectionObserver.observe(document, { childList: true, subtree: true });
      timer = setTimeout(visiblePosts, 200);
      enableBridge();
    }
  }
  function waitForEnable() {
    if (enabledAck) return Promise.resolve(true);
    return new Promise(resolve => {
      const request = { resolve };
      request.timer = setTimeout(() => { enableWaiters.delete(request); resolve(false); }, 3000);
      enableWaiters.add(request); enableBridge();
    });
  }
  function refreshPermission(force = false) {
    if (permissionPromise && !force) return permissionPromise;
    const version = ++permissionVersion;
    const pending = (async () => {
      try {
        const state = await send('GET_STATE');
        if (version !== permissionVersion) return false;
        expandedAllowed = state.expandedCollectionAllowed === true;
        applyPermission(state.collectionAllowed === true && state.vaultStatus === 'unlocked');
        return allowed ? await waitForEnable() : false;
      } catch {
        if (version === permissionVersion) applyPermission(false);
        return false;
      }
    })();
    permissionPromise = pending;
    pending.finally(() => { if (permissionPromise === pending) permissionPromise = undefined; });
    return pending;
  }
  function observeAccount() {
    if (!allowed) return;
    const current = account();
    if (previousAccount && previousAccount !== current) {
      domAllowed = false;
      accountEpoch++;
      registeredAccount = '';
      rejectWaiting();
    }
    if (current !== previousAccount) seen.clear();
    if (current || previousAccount) previousAccount = current;
  }
  async function collect(posts, accountUsername) {
    if (!allowed) return;
    if (!accountUsername || accountUsername !== account() || !bookmarksPage()) return;
    const fresh = [];
    for (const post of posts) {
      const key = `${accountUsername}:${post.id}`;
      const signature = JSON.stringify(post);
      if (seen.get(key) !== signature) { fresh.push(post); seen.set(key, signature); }
    }
    if (!fresh.length) return;
    try { await send('IMPORT_BOOKMARKS', { accountUsername, posts: fresh }); }
    catch { for (const post of fresh) seen.delete(`${accountUsername}:${post.id}`); }
  }
  function visiblePosts() {
    if (!allowed) return;
    const username = account();
    observeAccount();
    const isBookmarks = bookmarksPage();
    if (!domAllowed || !username || (!isBookmarks && !expandedAllowed)) return;
    if (isBookmarks && registeredAccount !== username) {
      registeredAccount = username;
      send('REGISTER_ACCOUNT', { accountUsername: username }).catch(() => { registeredAccount = ''; });
    }
    const posts = [];
    for (const article of document.querySelectorAll('.status[data-id]')) {
      if (article.closest('#revisit-root') || article.parentElement?.closest('.status[data-id]')) continue;
      if (!isBookmarks) {
        if (!article.querySelector('button.bookmark-icon.active')) continue;
        const rect = article.getBoundingClientRect();
        if (rect.bottom <= 0 || rect.top >= window.innerHeight || rect.right <= 0 || rect.left >= window.innerWidth) continue;
      }
      const post = postFromElement(article);
      if (post && (isBookmarks || !removed.has(`${username}:${post.id}`))) posts.push(post);
    }
    if (isBookmarks) collect(posts, username);
    else for (const post of posts) {
      const key = `observed:${username}:${post.id}`;
      const signature = JSON.stringify(post);
      if (seen.get(key) === signature) continue;
      seen.set(key, signature);
      send('SAVE_OBSERVED_BOOKMARK', { accountUsername: username, post }).catch(() => seen.delete(key));
    }
  }
  const collectionObserver = new MutationObserver(() => {
    if (!allowed) return;
    observeAccount(); clearTimeout(timer); timer = setTimeout(visiblePosts, 200);
  });
  window.addEventListener('scroll', () => {
    if (!allowed || !expandedAllowed) return;
    clearTimeout(timer); timer = setTimeout(visiblePosts, 200);
  }, { passive: true });
  window.addEventListener('message', event => {
    if (event.source !== window || event.origin !== location.origin || event.data?.source !== 'revisit-page') return;
    const data = event.data;
    if (data.type === 'READY') { initialize(); return; }
    if (data.channel !== channel) return;
    if (data.type === 'ENABLED') {
      if (allowed && data.requestId === enableRequest) { enabledAck = true; settleEnableWaiters(true); }
      return;
    }
    if (!allowed) return;
    if (data.type === 'POSTS' && Array.isArray(data.posts) && data.accountUsername === account()) {
      collect(data.posts, data.accountUsername);
    }
    if (data.type === 'MUTATION' && data.accountUsername === account()) {
      observeAccount();
      if (!/^\d+$/.test(data.postId || '') || typeof data.bookmarked !== 'boolean') return;
      if (!data.bookmarked) { seen.delete(`observed:${data.accountUsername}:${data.postId}`); removed.add(`${data.accountUsername}:${data.postId}`); }
      else removed.delete(`${data.accountUsername}:${data.postId}`);
      send('CONFIRM_BOOKMARK_CHANGE', { accountUsername: data.accountUsername, postId: data.postId, bookmarked: data.bookmarked }).catch(() => {});
      if (data.bookmarked && expandedAllowed) { clearTimeout(timer); timer = setTimeout(visiblePosts, 200); }
      for (const [id, request] of waiting) {
        if (data.postId !== request.postId || data.bookmarked !== request.bookmarked || data.accountUsername !== request.accountUsername) continue;
        clearTimeout(request.timer); waiting.delete(id);
        request.resolve({ bookmarked: data.bookmarked });
      }
    }
  });
  globalThis.RevisitPage = {
    ensureCollectionAllowed() {
      if (allowed && enabledAck) return Promise.resolve(true);
      return refreshPermission();
    },
    isCollectionAllowed: () => allowed && enabledAck,
    async setBookmark(postId, bookmarked, accountUsername) {
      if (!(await globalThis.RevisitPage.ensureCollectionAllowed())) throw new Error(globalThis.RevisitI18n.t('actionFailed'));
      observeAccount();
      if (!accountUsername || accountUsername !== account()) throw new Error(globalThis.RevisitI18n.t('actionFailed'));
      const expected = accountEpoch;
      const result = await send('NATIVE_BOOKMARK_ACTION', { postId, bookmarked, accountUsername });
      observeAccount();
      if (expected !== accountEpoch || accountUsername !== account() || result?.bookmarked !== bookmarked) throw new Error(globalThis.RevisitI18n.t('actionFailed'));
      return result;
    },
    waitForBookmarkChange(postId, bookmarked, accountUsername) {
      if (!allowed || !enabledAck) return Promise.reject(new Error(globalThis.RevisitI18n?.t('actionFailed') || 'Revisit is not ready.'));
      observeAccount();
      return new Promise((resolve, reject) => {
        if (!accountUsername || accountUsername !== account() || !/^\d+$/.test(postId || '') || typeof bookmarked !== 'boolean') { reject(new Error(globalThis.RevisitI18n.t('actionFailed'))); return; }
        const id = crypto.randomUUID();
        const timer = setTimeout(() => { waiting.delete(id); reject(new Error(globalThis.RevisitI18n.t('actionFailed'))); }, 15000);
        waiting.set(id, { resolve, reject, timer, postId, bookmarked, accountUsername });
      });
    },
  };
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'GET_PAGE_ACCOUNT') { sendResponse({ accountUsername: allowed ? account() : '' }); return; }
    if (message.type !== 'STATE_CHANGED') return;
    if (message.collectionAllowed === false) { expandedAllowed = false; applyPermission(false); }
    if (message.expandedCollectionAllowed === false) { expandedAllowed = false; seen.clear(); }
    refreshPermission(true);
  });
  initialize();
  refreshPermission();
  document.addEventListener('DOMContentLoaded', visiblePosts, { once: true });
})();
